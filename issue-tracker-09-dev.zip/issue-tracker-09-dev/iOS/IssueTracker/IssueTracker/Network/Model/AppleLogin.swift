//
//  AppleLogin.swift
//  IssueTracker
//
//  Created by 임승혁 on 2020/06/18.
//  Copyright © 2020 Cloud. All rights reserved.
//

import Foundation
import AuthenticationServices

struct AppleLogin: Codable {
    let token: String
}
