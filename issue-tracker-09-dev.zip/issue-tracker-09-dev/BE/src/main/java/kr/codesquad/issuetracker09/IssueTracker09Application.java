package kr.codesquad.issuetracker09;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IssueTracker09Application {

	public static void main(String[] args) {
		SpringApplication.run(IssueTracker09Application.class, args);
	}

}
